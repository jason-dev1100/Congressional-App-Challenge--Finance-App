/* FIRST YEAR SIMULATOR: settings and events */
/* Settings for the simulated job and bills */
const SIM={rate:12,schoolHours:15,summerHours:28,phone:40,gas:60,insurance:90,sub:15,apr:24,limit:500,startCash:150};
const MONTHS=["September","October","November","December","January","February","March","April","May","June","July","August"];
const SHORT=MONTHS.map(m=>m.slice(0,3));

/* Events: edit or add your own here.
   month: fixed month index (0 = September). requires: a flag set by an earlier choice.
   needsCard: only shows after the player has a credit card. maxMonth: last month it can appear.
   fx: chk (checking), sav (savings), inv (invested), happy, credit, set (flag), card (true = gets a card).
   run(): use instead of fx for choices with a random outcome. */
const EVENTS=[
 {id:"holiday",month:3,title:"Holiday gifts",text:"It's December, and you want to get gifts for family and friends.",choices:[
  {label:"Go big: $300",fx:{chk:-300,happy:12},note:"Holiday shopping is one of the biggest budget-busters of the year. Deciding on a gift budget before you shop helps."},
  {label:"Set a $120 gift budget",fx:{chk:-120,happy:8},note:"Setting a limit before you shop keeps you in control."},
  {label:"Make gifts and write cards: $30",fx:{chk:-30,happy:6},note:"Thoughtful doesn't have to mean expensive."}]},
 {id:"card",month:5,title:"You turned 18",text:"Happy birthday! Your bank offers you a student credit card with a $500 limit and a 24% APR.",choices:[
  {label:"Accept the card",fx:{card:true},note:"A credit card builds your credit score when you pay on time and keep your balance low. Late payments do the opposite. In real life, a score usually shows up after about 6 months of history. Here it starts now so you can watch it change."},
  {label:"Say no for now",fx:{},note:"That's a fine choice. You can build credit later, and some people start as an authorized user on a parent's card."}]},
 {id:"prom",month:8,title:"Prom",text:"Prom is coming up. Tickets, outfit, dinner, and photos add up fast.",choices:[
  {label:"The full experience: $400",fx:{chk:-400,happy:15},note:"Big events are worth planning for months ahead, so the cost doesn't hit all at once."},
  {label:"Budget version: $180",fx:{chk:-180,happy:11},note:"Renting, borrowing, and splitting costs with friends can cut the price in half."},
  {label:"Skip it",fx:{happy:-12},note:"Saving matters, but so do experiences. A good budget leaves room for both."}]},
 {id:"car",title:"Check engine light",text:"Your car's check engine light comes on. The mechanic says it's a $450 repair.",choices:[
  {label:"Fix it now: $450",fx:{chk:-450},note:"This is exactly what an emergency fund is for."},
  {label:"Put it off",fx:{happy:-4,set:"carDelay"},note:"Putting off repairs often makes them more expensive. We'll see what happens."}]},
 {id:"carBig",requires:"carDelay",forced:true,title:"Your car broke down",text:"The problem you put off got worse. It's now a $950 repair, plus $120 for the tow.",choices:[
  {label:"Pay for it",fx:{chk:-1070,happy:-10},note:"Waiting on the $450 repair cost you $620 extra. Small problems tend to become big ones."}]},
 {id:"trip",title:"Beach weekend",text:"Your friends are planning a weekend at Myrtle Beach. Your share would be $250.",choices:[
  {label:"Go: $250",fx:{chk:-250,happy:14},note:"Fun is part of a budget. What matters is whether you planned for it."},
  {label:"Suggest a day trip instead: $60",fx:{chk:-60,happy:8},note:"Offering a cheaper plan lets you have fun without wrecking your budget."},
  {label:"Skip it",fx:{happy:-8},note:"Saying no is easier when you know what you're saving for."}]},
 {id:"phone",title:"Cracked screen",text:"You dropped your phone and cracked the screen.",choices:[
  {label:"Repair it: $120",fx:{chk:-120},note:"Repairing is usually much cheaper than replacing."},
  {label:"Buy the newest phone: $900",fx:{chk:-900,happy:10},note:"A new phone feels great, but replacing one that can be fixed is a want, not a need."},
  {label:"Live with the crack",fx:{happy:-5},note:"Free for now, but cracks tend to spread."}]},
 {id:"scam",title:"You won a prize?",text:"A text says: \"Congrats! You won a $500 gift card. Pay $20 shipping to claim it.\"",choices:[
  {label:"Pay the $20",fx:{chk:-220,happy:-10},note:"It was a scam. They used your card number to charge another $200. Real prizes never make you pay to get them."},
  {label:"Delete and block it",fx:{happy:2},note:"Good call. Being asked to pay to receive a prize is a classic scam sign."}]},
 {id:"hours",title:"Extra shifts",text:"Your manager offers you extra weekend shifts this month, worth about $160 after taxes.",choices:[
  {label:"Take the shifts",fx:{chk:160,happy:-6},note:"More hours means more money, but keep an eye on schoolwork and sleep."},
  {label:"Keep your schedule",fx:{happy:2},note:"Your time has value too."}]},
 {id:"concert",title:"Concert tickets",text:"Your favorite artist is playing in Charlotte. Tickets are $180.",choices:[
  {label:"Buy from the official site: $180",fx:{chk:-180,happy:12},note:"Buying from official sellers protects you from fake tickets."},
  {label:"Buy from a stranger online: $90",fx:{chk:-90,happy:-12},note:"The tickets were fake and the seller vanished. Payment apps usually can't recover money sent to a scammer."},
  {label:"Skip it",fx:{happy:-5},note:"There will be other concerts."}]},
 {id:"lend",title:"A friend needs money",text:"A friend asks to borrow $100 and promises to pay you back next month.",choices:[
  {label:"Lend it",run(){const back=Math.random()<.5;return{fx:{chk:back?0:-100,happy:back?4:-6},note:back?"Your friend paid you back. It doesn't always go that way.":"Your friend never paid you back. A good rule: only lend what you'd be OK never seeing again."}}},
  {label:"Politely say no",fx:{happy:-2},note:"Protecting your money doesn't make you a bad friend."}]},
 {id:"crypto",title:"A hot tip",text:"A coworker says a new crypto coin is \"guaranteed\" to triple and wants you to put in $200.",choices:[
  {label:"Buy the coin: $200",run(){const win=Math.random()<.25;return{fx:{chk:win?120:-170,happy:win?6:-8},note:win?"You got lucky, and your $200 became $320. Most hyped coins crash, though. That's gambling, not investing.":"The coin crashed, and your $200 is now worth $30. Nothing in investing is guaranteed."}}},
  {label:"Put $200 in an index fund instead",fx:{chk:-200,inv:200},note:"An index fund spreads your money across hundreds of companies. It still goes up and down, but it's far less risky."},
  {label:"Pass",fx:{},note:"A \"guaranteed\" return is a red flag."}]},
 {id:"sneakers",title:"Big sale",text:"The sneakers you've wanted are 40% off: $110 instead of $180.",choices:[
  {label:"Buy them: $110",fx:{chk:-110,happy:8},note:"A sale only saves money if you were going to buy it anyway."},
  {label:"Pass",fx:{},note:"Not spending $110 saves more than spending $110 to \"save\" $70."}]},
 {id:"sub",title:"Free trial ended",text:"A free trial you forgot about just turned into a $15-a-month subscription.",choices:[
  {label:"Cancel it",fx:{chk:-15},note:"When you start a free trial, set a reminder to cancel before it ends."},
  {label:"Keep it",fx:{chk:-15,happy:3,set:"sub"},note:"$15 a month is $180 a year. It's now one of your monthly bills."}]},
 {id:"wallet",title:"Lost wallet",text:"You lost your wallet with $40 cash inside, and replacing your license costs $14.",choices:[
  {label:"Ugh. OK.",fx:{chk:-54,happy:-6},note:"If you lose a debit card, lock or report it right away so no one else can use it."}]},
 {id:"gift",title:"Surprise money",text:"Your grandparents sent you $100.",choices:[
  {label:"Save it",fx:{sav:100,happy:2},note:"Saving money you weren't expecting is one of the easiest ways to grow your savings."},
  {label:"Save half, spend half",fx:{sav:50,chk:50,happy:5},note:"Splitting it lets you enjoy some and still make progress."},
  {label:"Spend it",fx:{chk:100,happy:7},note:"It's yours to enjoy. Just make it a choice, not a habit."}]},
 {id:"apps",maxMonth:4,title:"College applications",text:"You're applying to four colleges, and each application fee is $75.",choices:[
  {label:"Pay $300",fx:{chk:-300},note:"Many colleges offer fee waivers. It's always worth asking."},
  {label:"Ask your counselor about fee waivers",fx:{chk:-75,happy:3},note:"Three schools waived the fee. Asking saved you $225."}]},
 {id:"storecard",needsCard:true,title:"Store card offer",text:"At checkout, the cashier says you'll save $15 today if you open a store credit card with a 30% APR.",choices:[
  {label:"Open it",fx:{chk:15,credit:-10},note:"Each new card application is a hard inquiry that can lower your score a little. Saving $15 usually isn't worth it."},
  {label:"No thanks",fx:{},note:"Store cards often have very high APRs."}]},
 {id:"gas",title:"Gas prices jump",text:"Gas prices went up this month. You spend an extra $35 getting to school and work.",choices:[
  {label:"OK",fx:{chk:-35},note:"Keeping a small cushion in checking helps with surprises like this."}]}
];
