/* NEED OR WANT? game items
   t: the item, d: optional extra detail, a: 0 = Need, 1 = Want, e: explanation
   Each round picks 8 at random. */
const NEEDS_WANTS=[
 {t:"Car insurance",d:"You drive yourself to school and work.",a:0,e:"Driving without insurance is illegal in almost every state."},
 {t:"New sneakers",d:"Your current pair still fits and isn't worn out.",a:1,e:"Shoes are a need, but replacing a pair that still works is a want."},
 {t:"Gas to get to your job",a:0,e:"No gas, no job, no paycheck."},
 {t:"A streaming subscription",a:1,e:"Nice to have, but you can cancel it and still get by."},
 {t:"Fast food with friends",d:"Third time this week.",a:1,e:"Food is a need. Eating out instead of eating at home is a want."},
 {t:"Groceries",a:0,e:"Basic food is a need. It's also much cheaper than eating out."},
 {t:"The newest phone",d:"Your current phone works fine.",a:1,e:"A working phone can be a need. Upgrading one that works is a want."},
 {t:"Work uniform",d:"Your job requires it.",a:0,e:"If you need it to keep your job, it's a need."},
 {t:"Concert tickets",a:1,e:"A fun experience, but a want. Budget for it in your 30%."},
 {t:"Phone bill",d:"Your manager texts you your shifts.",a:0,e:"When your job depends on reaching you, basic phone service is a need."},
 {t:"In-game skins",a:1,e:"Small purchases add up fast. $10 a week is $520 a year."},
 {t:"A winter coat",d:"You don't have one, and it's December.",a:0,e:"Staying warm is a basic need."}
];

/* SPOT THE SCAM game items
   t: the message, d: optional context, a: 0 = Scam, 1 = Legit, e: explanation
   Each round picks 6 at random. */
const SCAMS=[
 {t:"\"Congrats! You won a $500 gift card. Pay a $20 shipping fee to claim it.\"",a:0,e:"Real prizes never ask you to pay to receive them."},
 {t:"\"Your bank account is locked. Click this link and enter your password now.\"",a:0,e:"Banks don't ask for passwords by text or email. Call the number on your card instead."},
 {t:"\"Work from home! Earn $900 a week. We'll mail you a check, deposit it, and send part back to us.\"",a:0,e:"This is a fake-check scam. The check bounces later and you owe the bank the money."},
 {t:"\"Your new W-2 is ready. Log in to your employee portal to view it.\"",d:"Sent in late January from your actual employer.",a:1,e:"Employers must provide W-2s by January 31. Still, go to the portal yourself instead of clicking a link."},
 {t:"\"I'll pay double for your concert tickets. Just send them first and I'll pay after.\"",a:0,e:"Never send goods or tickets before payment clears, especially to strangers."},
 {t:"\"Hey it's your cousin, new number. I'm stuck and need $200 in gift cards ASAP.\"",a:0,e:"Gift card requests plus urgency is a classic scam. Call your cousin's real number to check."},
 {t:"\"Your card ending in 4821 was used for $3.49 at a coffee shop. Reply YES if this was you.\"",d:"You did buy coffee, and the alert came from your bank's usual number.",a:1,e:"Many banks send fraud alerts like this. A real alert won't ask for your password or full card number."},
 {t:"\"Invest $100 in this crypto coin. Guaranteed 10x returns in a week!\"",a:0,e:"No investment can guarantee returns. \"Guaranteed\" plus \"fast\" is a big red flag."},
 {t:"\"Your package can't be delivered. Pay $1.99 here to reschedule.\"",d:"You didn't order anything.",a:0,e:"A common text scam used to steal card numbers."},
 {t:"\"Your FAFSA confirmation is ready.\"",d:"Sent from studentaid.gov after you submitted the form.",a:1,e:"Official messages come from .gov addresses and don't ask for payment. The FAFSA is free."}
];
