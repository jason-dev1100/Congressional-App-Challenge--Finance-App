/* MONEY TERMS
   Used by the flashcards AND the matching game.
   Format: ["Term", "Definition"],
   Keep definitions short (one line) so they fit on the cards. */
const TERMS=[
 ["Gross pay","What you earn before anything is taken out"],
 ["Net pay","What actually lands in your bank account"],
 ["Budget","A plan for your money before you spend it"],
 ["Emergency fund","Savings set aside for surprise costs, like a car repair"],
 ["Compound interest","Earning returns on your money and on past returns"],
 ["APR","The yearly interest rate charged on a loan or credit card"],
 ["Credit score","A number from 300 to 850 that shows how you handle debt"],
 ["Roth IRA","A retirement account where qualified withdrawals are tax-free"],
 ["FICA","Social Security and Medicare taxes taken from your paycheck"],
 ["Debit card","Spends money straight from your checking account"],
 ["Index fund","One investment that holds many companies' stocks at once"],
 ["W-2","The form your employer sends showing what you earned and paid in taxes"],
 ["W-4","The form you fill out at a new job to set how much tax is withheld"],
 ["Inflation","Prices rising over time, so each dollar buys a little less"],
 ["Net worth","What you own minus what you owe"],
 ["Overdraft","Spending more than what's in your checking account"],
 ["Credit utilization","How much of your credit limit you're using, as a percent"],
 ["Diversification","Spreading money across many investments to lower risk"],
 ["Pay yourself first","Moving money into savings before you spend any"],
 ["Interest rate","The cost of borrowing money, or what you earn for saving it"]
];
