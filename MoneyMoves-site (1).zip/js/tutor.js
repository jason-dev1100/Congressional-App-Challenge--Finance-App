/* AI tutor */
const TUTOR_RULES=`You are Penny, a friendly financial literacy tutor on MoneyMoves, a website for high school students in the United States.
- Explain money topics (paychecks, taxes, budgeting, saving, investing, credit, debt, college costs, first jobs) in plain language a 15-year-old understands.
- Keep answers short: 2 to 5 sentences, or a short list. Use a quick example with realistic teen numbers when it helps.
- Be accurate. If something depends on the state or the person's situation, say so. If you're not sure, say that.
- Never recommend specific stocks, crypto, or products. For big decisions, suggest talking with a parent, guardian, or trusted adult.
- If the question isn't about money, politely steer back to money topics.
- Plain text only, no markdown headings or bold.`;
const tLog=$("tutorLog"),tForm=$("tutorForm"),tIn=$("tutorInput"),tSend=$("tutorSend"),tBox=$("tutor"),tFab=$("tutorOpen");
const history=[];let busy=false,samplePromise=null;
function getSample(){return samplePromise??=(window.claude?.use?window.claude.use("sample"):Promise.resolve(null)).catch(()=>null)}
function openTutor(){tBox.hidden=false;tFab.hidden=true;tFab.setAttribute("aria-expanded","true");tIn.focus();getSample()}
function closeTutor(){tBox.hidden=true;tFab.hidden=false;tFab.setAttribute("aria-expanded","false");tFab.focus()}
tFab.onclick=openTutor;$("tutorClose").onclick=closeTutor;
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!tBox.hidden)closeTutor()});
function addMsg(cls,text){const d=document.createElement("div");d.className="msg "+cls;d.textContent=text;tLog.appendChild(d);tLog.scrollTop=tLog.scrollHeight;return d}
async function ask(q){
  q=q.trim();if(!q||busy)return;
  $("chips")?.remove();
  addMsg("me",q);history.push({role:"user",content:q});
  busy=true;tSend.disabled=true;tIn.value="";
  const bubble=addMsg("bot","Thinking…");
  const sample=await getSample();
  if(!sample){bubble.classList.add("err");bubble.textContent="The tutor isn't available here. Open this page on claude.ai while signed in to chat with Penny.";history.pop();busy=false;tSend.disabled=false;return}
  const msgs=history.slice(-12).map((m,i,a)=>i===0?{role:m.role,content:(m.role==="user"?TUTOR_RULES+"\n\nStudent's question: ":"")+m.content}:m);
  if(msgs[0].role!=="user")msgs.unshift({role:"user",content:TUTOR_RULES+"\n\n(Conversation continues.)"});
  try{
    const r=await sample(msgs,{cache:false,modelTier:"quick",onText:({text})=>{if(text){bubble.textContent=text;tLog.scrollTop=tLog.scrollHeight}}});
    bubble.textContent=r.text||bubble.textContent;history.push({role:"assistant",content:bubble.textContent});
  }catch(err){
    bubble.classList.add("err");history.pop();
    bubble.textContent=err?.code==="rate_limited"?"Too many questions at once. Wait a minute and try again.":err?.code==="not_granted"?"The tutor needs permission to answer. Allow it when your browser asks, then try again.":"Something went wrong getting an answer. Try asking again.";
  }
  busy=false;tSend.disabled=false;tIn.focus();
}
tForm.addEventListener("submit",e=>{e.preventDefault();ask(tIn.value)});
document.querySelectorAll(".chip").forEach(c=>c.onclick=()=>ask(c.textContent));
