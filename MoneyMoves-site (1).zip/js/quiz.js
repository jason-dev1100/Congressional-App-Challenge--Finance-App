/* quiz */
let Q=shuffle(QPOOL).slice(0,10),qi=0,score=0;
function renderQ(){
  const box=$("quizbox");
  if(qi>=Q.length){
    const msg=score===Q.length?"Perfect score. You're ready.":score>=4?"Solid. Review any you missed above.":"Good start. Read the lessons and try again.";
    box.innerHTML=`<p class="eyebrow">Results</p><h3 style="font-size:2rem;margin:10px 0"><span class="num">${score}/${Q.length}</span></h3><p>${msg}</p><div class="qnav"><button class="btn primary" id="again">Retake quiz</button></div>`;
    $("again").onclick=()=>{Q=shuffle(QPOOL).slice(0,10);qi=0;score=0;renderQ()};return;
  }
  const it=Q[qi];
  box.innerHTML=`<div class="qtop"><span>Question ${qi+1} of ${Q.length}</span><span>Score ${score}</span></div>
  <div class="bar"><i style="width:${qi/Q.length*100}%"></i></div>
  <h3>${it.q}</h3><div class="opts">${shuffle(it.o.map((o,i)=>[o,i])).map(([o,i])=>`<button class="opt" data-i="${i}">${o}</button>`).join("")}</div><div id="fb"></div>`;
  box.querySelectorAll(".opt").forEach(b=>b.onclick=()=>{
    const pick=+b.dataset.i;
    box.querySelectorAll(".opt").forEach(x=>{x.disabled=true;if(+x.dataset.i===it.a)x.classList.add("right")});
    if(pick===it.a)score++;else b.classList.add("wrong");
    $("fb").innerHTML=`<div class="explain"><b>${pick===it.a?"Correct.":"Not quite."}</b> ${it.e}</div><div class="qnav"><button class="btn primary" id="next">${qi===Q.length-1?"See results":"Next question"}</button></div>`;
    $("next").onclick=()=>{qi++;renderQ()};$("next").focus();
  });
}
renderQ();
