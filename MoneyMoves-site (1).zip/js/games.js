/* games */
document.querySelectorAll("#games .gtab").forEach(t=>t.onclick=()=>{
  document.querySelectorAll("#games .gtab").forEach(x=>x.setAttribute("aria-selected",x===t));
  document.querySelectorAll("#games .game").forEach(g=>g.hidden=g.id!==t.dataset.g);
});


/* matching */
let mSel=null,mLeft=0,mMiss=0;
function newMatch(){
  const set=shuffle(TERMS).slice(0,6);mSel=null;mLeft=set.length;mMiss=0;
  $("mterms").innerHTML=shuffle(set).map(([t])=>`<button class="mcard term" data-k="${esc(t)}">${esc(t)}</button>`).join("");
  $("mdefs").innerHTML=shuffle(set).map(([t,d])=>`<button class="mcard" data-k="${esc(t)}">${esc(d)}</button>`).join("");
  document.querySelectorAll("#g-match .mcard").forEach(b=>b.onclick=()=>pickMatch(b));
  mStat();
}
function mStat(){$("mstat").textContent=`${6-mLeft}/6 matched · ${mMiss} misses`}
function pickMatch(b){
  if(b.classList.contains("done"))return;
  const isTerm=b.classList.contains("term");
  if(!mSel||mSel.classList.contains("term")===isTerm){
    mSel?.classList.remove("sel");mSel=b;b.classList.add("sel");return;
  }
  const a=mSel;mSel=null;a.classList.remove("sel");
  if(a.dataset.k===b.dataset.k){
    [a,b].forEach(x=>{x.classList.add("done");x.disabled=true});mLeft--;mStat();
    if(!mLeft){
      const p=document.createElement("div");p.className="done-box";p.style.marginTop="18px";
      p.innerHTML=`<p><b>All matched${mMiss?` with ${mMiss} miss${mMiss>1?"es":""}`:" with zero misses"}.</b> ${mMiss?"Play again to beat it.":"Nice work."}</p><button class="btn primary">New set of terms</button>`;
      p.querySelector("button").onclick=()=>{p.remove();newMatch()};
      $("g-match").appendChild(p);
    }
  }else{
    mMiss++;mStat();[a,b].forEach(x=>{x.classList.add("bad");setTimeout(()=>x.classList.remove("bad"),400)});
  }
}
newMatch();

/* two-choice games */
function twoChoice(el,cfg){
  let deck,i,score;
  const start=()=>{deck=shuffle(cfg.items).slice(0,cfg.n);i=0;score=0;show()};
  const show=()=>{
    if(i>=deck.length){
      el.innerHTML=`<div class="done-box"><p class="eyebrow">Round over</p><h3 style="font-size:2rem"><span class="num">${score}/${deck.length}</span></h3><p>${score===deck.length?cfg.perfect:score>=deck.length-2?"Close. Play again for a new mix.":"Keep practicing. Each round uses different examples."}</p><button class="btn primary">Play again</button></div>`;
      el.querySelector("button").onclick=start;return;
    }
    const it=deck[i];
    el.innerHTML=`<div class="gbar"><p>${cfg.prompt}</p><span class="gstat">${i+1} of ${deck.length} · score ${score}</span></div>
    <div class="sorter"><div class="scard"><span class="eyebrow">${cfg.label}</span><h3>${esc(it.t)}</h3>${it.d?`<p>${esc(it.d)}</p>`:""}</div>
    <div class="sbtns">${cfg.choices.map((c,k)=>`<button class="btn ${k?"ghost":"primary"}" data-c="${k}">${c}</button>`).join("")}</div><div id="${el.id}-fb"></div></div>`;
    el.querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{
      const ok=+b.dataset.c===it.a;if(ok)score++;
      el.querySelectorAll("[data-c]").forEach(x=>x.disabled=true);
      $(el.id+"-fb").innerHTML=`<div class="explain" style="border-color:var(${ok?"--green":"--red"})"><b>${ok?"Right.":"Not quite."}</b> It's ${cfg.choices[it.a].toLowerCase()}. ${esc(it.e)}</div><div class="qnav"><button class="btn primary" id="${el.id}-next">${i===deck.length-1?"See score":"Next"}</button></div>`;
      $(el.id+"-next").onclick=()=>{i++;show()};$(el.id+"-next").focus();
    });
  };
  start();
}
twoChoice($("g-need"),{n:8,label:"Item",prompt:"Is this a need or a want? Think about whether you could live or work without it.",choices:["Need","Want"],perfect:"Perfect. You know where your money should go first.",items:NEEDS_WANTS});
twoChoice($("g-scam"),{n:6,label:"Message",prompt:"Read the message. Is it a scam or legit?",choices:["Scam","Legit"],perfect:"Perfect. Scammers won't get far with you.",items:SCAMS});
