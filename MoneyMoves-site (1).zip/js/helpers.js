/* Small helper functions used everywhere. Load this file first. */
const $=id=>document.getElementById(id);
const fmt=n=>"$"+Math.round(n).toLocaleString("en-US");
function shuffle(a){a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
const esc=s=>s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const money=n=>(n<0?"−$":"$")+Math.abs(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const rnd=(a,b,s=1)=>a+s*Math.floor(Math.random()*((b-a)/s+1));
const pick=a=>a[Math.floor(Math.random()*a.length)];
const parseNum=s=>parseFloat(String(s).replace(/−/g,"-").replace(/[$,%\s]/g,""));
const showAns=(a,u)=>u==="$"?money(a):u==="%"?(Math.round(a*10)/10)+"%":`${Math.round(a*10)/10} ${u}`;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const floor5=v=>Math.max(0,Math.floor(v/5)*5);
