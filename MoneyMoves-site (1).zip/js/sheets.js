/* practice sheets */
const SHEETS={
 stub:{title:"Read a pay stub",gen(){const h=rnd(10,30),r=rnd(1100,1600,25)/100,g=h*r,ss=g*.062,md=g*.0145;return{intro:`Jordan worked <b>${h} hours</b> this pay period at <b>${money(r)} an hour</b>. Jordan lives in a state with no income tax, and no federal income tax was withheld. Fill in Jordan's pay stub.`,
  fields:[{l:"Gross pay",hint:"Hours × hourly rate",a:g,u:"$",how:`${h} × ${money(r)} = ${money(g)}`},
   {l:"Social Security",hint:"6.2% of gross pay",a:ss,u:"$",how:`${money(g)} × 0.062 = ${money(ss)}`},
   {l:"Medicare",hint:"1.45% of gross pay",a:md,u:"$",how:`${money(g)} × 0.0145 = ${money(md)}`},
   {l:"Net pay",hint:"Gross minus both taxes",a:g-ss-md,u:"$",how:`${money(g)} − ${money(ss)} − ${money(md)} = ${money(g-ss-md)}`}]}}},
 budget:{title:"Plan a monthly budget",gen(){const n=rnd(500,1200,50),ph=pick([35,40,45,50]),gas=rnd(60,140,10),ins=rnd(80,160,10),goal=rnd(4,12)*100,sv=n*.2;return{intro:`Maya takes home <b>${fmt(n)} a month</b> from her job. Her monthly bills are a <b>${fmt(ph)}</b> phone plan, <b>${fmt(gas)}</b> for gas, and <b>${fmt(ins)}</b> for car insurance. She's saving for a <b>${fmt(goal)}</b> laptop. She uses the 50/30/20 rule.`,
  fields:[{l:"Needs budget",hint:"50% of take-home pay",a:n*.5,u:"$",how:`${fmt(n)} × 0.5 = ${money(n*.5)}`},
   {l:"Total monthly bills",hint:"Phone + gas + insurance",a:ph+gas+ins,u:"$",how:`${fmt(ph)} + ${fmt(gas)} + ${fmt(ins)} = ${money(ph+gas+ins)}`},
   {l:"Needs money left after bills",hint:"Needs budget minus bills. Use a minus sign if bills go over.",a:n*.5-(ph+gas+ins),u:"$",how:`${money(n*.5)} − ${money(ph+gas+ins)} = ${money(n*.5-(ph+gas+ins))}${n*.5<ph+gas+ins?". Her bills are more than her needs budget, so she'd have to take money from wants.":""}`},
   {l:"Monthly savings",hint:"20% of take-home pay",a:sv,u:"$",how:`${fmt(n)} × 0.2 = ${money(sv)}`},
   {l:"Months to afford the laptop",hint:"Round up to a whole month",a:Math.ceil(goal/sv),u:"months",tol:0,how:`${fmt(goal)} ÷ ${money(sv)} = ${(goal/sv).toFixed(2)}, which rounds up to ${Math.ceil(goal/sv)} months`}]}}},
 credit:{title:"Credit card check-up",gen(){const lim=pick([1000,1500,2000,2500,3000]),bal=rnd(4,18)*lim/20,apr=pick([19,22,24,26]),mi=bal*apr/1200;return{intro:`Alex has a credit card with a <b>${fmt(lim)}</b> limit and a <b>${apr}% APR</b>. The current balance is <b>${fmt(bal)}</b>. Alex isn't paying it off in full.`,
  fields:[{l:"Credit utilization",hint:"Balance ÷ limit × 100",a:bal/lim*100,u:"%",tol:1,how:`${fmt(bal)} ÷ ${fmt(lim)} × 100 = ${Math.round(bal/lim*1000)/10}%. ${bal/lim<.3?"That's under 30%.":"That's over the 30% guideline."}`},
   {l:"Monthly interest rate",hint:"APR ÷ 12",a:apr/12,u:"%",tol:.05,how:`${apr}% ÷ 12 = ${(apr/12).toFixed(2)}%`},
   {l:"Interest charged this month",hint:"Balance × APR ÷ 12",a:mi,u:"$",how:`${fmt(bal)} × ${apr/100} ÷ 12 = ${money(mi)}`},
   {l:"Interest over a year if the balance stays the same",hint:"Monthly interest × 12",a:mi*12,u:"$",tol:1,how:`${money(mi)} × 12 = ${money(mi*12)}. That money buys nothing. Paying the balance in full avoids it.`}]}}}
};
let shKey="stub",shCur;
function shNew(){shCur=SHEETS[shKey].gen();shRender()}
function shRender(){
  const el=$("sheet");
  el.innerHTML=`<div class="gbar"><p class="eyebrow">${SHEETS[shKey].title}</p><span class="gstat" id="shscore"></span></div>
  <p class="sintro">${shCur.intro}</p>
  <div class="srows">${shCur.fields.map((f,i)=>`<div class="srow"><label for="sh${i}">${i+1}. ${f.l}<small>${f.hint}</small></label><span class="unitbox"><i>${f.u==="$"?"$":""}</i><input id="sh${i}" inputmode="decimal" autocomplete="off"><i>${f.u==="$"?"":f.u}</i></span><span class="smark" id="shm${i}"></span></div>`).join("")}</div>
  <div class="sbtns3"><button class="btn primary" id="shcheck">Check answers</button><button class="btn ghost" id="shshow">Show answers</button><button class="btn ghost" id="shnew">New numbers</button></div>`;
  $("shcheck").onclick=()=>{
    let right=0,blank=0;
    shCur.fields.forEach((f,i)=>{
      const raw=$("sh"+i).value.trim(),m=$("shm"+i),tol=f.tol??.5;
      if(!raw){blank++;m.className="smark";m.textContent="";return}
      const ok=Math.abs(parseNum(raw)-f.a)<=tol;if(ok)right++;
      m.className="smark "+(ok?"ok":"no");m.textContent=ok?"✓ Correct":"✗ Not quite. Check your math and try again.";
    });
    $("shscore").textContent=`${right}/${shCur.fields.length} correct${blank?` · ${blank} blank`:""}`;
  };
  $("shshow").onclick=()=>shCur.fields.forEach((f,i)=>{const m=$("shm"+i);m.className="smark ok";m.textContent=`Answer: ${showAns(f.a,f.u)}. ${f.how}`});
  $("shnew").onclick=shNew;
}
document.querySelectorAll("#shtabs .gtab").forEach(t=>t.onclick=()=>{
  document.querySelectorAll("#shtabs .gtab").forEach(x=>x.setAttribute("aria-selected",x===t));
  shKey=t.dataset.s;shNew();
});
shNew();
