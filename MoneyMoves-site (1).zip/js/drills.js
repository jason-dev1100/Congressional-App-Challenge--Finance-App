/* drills */
const DRILLS={
 fica:{name:"Paycheck taxes",gen(){const g=rnd(200,900,10);return{q:`You earn ${fmt(g)} gross on a paycheck. How much is taken out for FICA (7.65%)?`,a:g*.0765,tol:.5,u:"$",how:`${fmt(g)} × 0.0765 = ${money(g*.0765)}`}}},
 net:{name:"Take-home pay",gen(){const g=rnd(200,900,10);return{q:`Your gross pay is ${fmt(g)}. Only FICA (7.65%) is taken out. What's your take-home pay?`,a:g*(1-.0765),tol:.5,u:"$",how:`${fmt(g)} × 0.9235 = ${money(g*.9235)}. Multiplying by 0.9235 is the same as subtracting 7.65%.`}}},
 monthly:{name:"Hourly to monthly",gen(){const w=rnd(1100,1800,25)/100,h=rnd(8,25);return{q:`You make ${money(w)} an hour and work ${h} hours a week. About how much do you earn per month before taxes?`,a:w*h*52/12,tol:1,u:"$",how:`${money(w)} × ${h} hours × 52 weeks ÷ 12 months = ${money(w*h*52/12)}`}}},
 split:{name:"50/30/20 budget",gen(){const n=rnd(400,1600,50),[c,p]=pick([["needs",.5],["wants",.3],["savings",.2]]);return{q:`Your monthly take-home pay is ${fmt(n)}. Using the 50/30/20 rule, how much goes to ${c}?`,a:n*p,tol:.5,u:"$",how:`${c[0].toUpperCase()+c.slice(1)} get ${p*100}%: ${fmt(n)} × ${p} = ${money(n*p)}`}}},
 goal:{name:"Savings goals",gen(){const g=rnd(3,24)*50,m=pick([3,4,5,6,8,10,12]),thing=pick(["new laptop","prom","a used car fund","a summer trip","concert tickets","a phone"]);return{q:`You want ${fmt(g)} for ${thing} in ${m} months. How much do you need to save each month?`,a:g/m,tol:.5,u:"$",how:`${fmt(g)} ÷ ${m} months = ${money(g/m)} per month`}}},
 r72:{name:"Rule of 72",gen(){const r=pick([2,3,4,6,8,9,12]);return{q:`Your investment earns ${r}% a year. Using the Rule of 72, about how many years until your money doubles?`,a:72/r,tol:.1,u:"years",how:`72 ÷ ${r} = ${72/r} years`}}},
 interest:{name:"Credit card interest",gen(){const b=rnd(200,2500,50),apr=pick([18,20,22,24,27]);return{q:`You owe ${fmt(b)} on a credit card with a ${apr}% APR. About how much interest is charged for one month?`,a:b*apr/1200,tol:.5,u:"$",how:`Monthly rate = ${apr}% ÷ 12. ${fmt(b)} × ${apr/100} ÷ 12 = ${money(b*apr/1200)}`}}},
 util:{name:"Credit utilization",gen(){const lim=pick([500,1000,1500,2000,2500,3000,5000]),bal=rnd(1,19)*lim/20;return{q:`Your credit limit is ${fmt(lim)} and your balance is ${fmt(bal)}. What's your credit utilization?`,a:bal/lim*100,tol:1,u:"%",how:`${fmt(bal)} ÷ ${fmt(lim)} × 100 = ${Math.round(bal/lim*1000)/10}%. ${bal/lim<.3?"That's under 30%, which is good.":"That's over 30%, which can lower your score."}`}}}
};
let dCur,dRetry=[],dC=0,dT=0,dS=0,dBest=0,dDone=false;
function dNext(){
  const sel=$("dtopic").value;
  const key=sel!=="all"?sel:(dRetry.length&&Math.random()<.5?dRetry.shift():pick(Object.keys(DRILLS)));
  dCur={key,...DRILLS[key].gen()};dDone=false;
  $("dtag").textContent=DRILLS[key].name+(sel==="all"&&dCur.retry?"":"");
  $("dq").textContent=dCur.q;
  $("dpre").textContent=dCur.u==="$"?"$":"";$("dpost").textContent=dCur.u==="$"?"":dCur.u;
  $("dans").value="";$("dans").disabled=false;$("dfb").innerHTML="";$("dcheck").textContent="Check";
}
function dStats(){$("dstreak").textContent=dS;$("dbest").textContent=dBest;$("dscore").textContent=`${dC}/${dT}`}
$("dform").addEventListener("submit",e=>{
  e.preventDefault();
  if(dDone){dNext();$("dans").focus();return}
  const v=parseNum($("dans").value);
  if(isNaN(v)){$("dfb").innerHTML=`<div class="explain" style="border-color:var(--gold)">Type a number first, like 12.50.</div>`;return}
  dDone=true;dT++;
  const ok=Math.abs(v-dCur.a)<=dCur.tol;
  if(ok){dC++;dS++;dBest=Math.max(dBest,dS)}else{dS=0;if($("dtopic").value==="all")dRetry.push(dCur.key)}
  dStats();$("dans").disabled=true;
  $("dfb").innerHTML=`<div class="explain" style="border-color:var(${ok?"--green":"--red"})"><b>${ok?"Correct.":"Not quite. The answer is "+showAns(dCur.a,dCur.u)+"."}</b> ${dCur.how}${!ok&&$("dtopic").value==="all"?" You'll see this type again soon.":""}</div>`;
  $("dcheck").textContent="Next problem";$("dcheck").focus();
});
$("dtopic").onchange=()=>{dRetry=[];dNext()};
dStats();dNext();
