/* budget */
function budget(){
  const w=+$("wage").value||0,h=+$("hours").value||0,t=+$("taxrate").value||0;
  const gross=w*h*52/12, net=gross*(1-0.0765-t/100);
  $("gross").textContent=fmt(gross); $("net").textContent=fmt(Math.max(net,0));
  $("needs").textContent=fmt(net*.5); $("wants").textContent=fmt(net*.3); $("saves").textContent=fmt(net*.2);
}
["wage","hours","taxrate"].forEach(id=>$(id).addEventListener("input",budget));
budget();

/* growth */
function project(start,m,r){
  const months=(65-start)*12, mr=r/100/12; let bal=0; const pts=[{age:start,bal:0,paid:0}];
  for(let i=1;i<=months;i++){bal=bal*(1+mr)+m; if(i%12===0) pts.push({age:start+i/12,bal,paid:m*i});}
  return pts;
}
function css(v){return getComputedStyle(document.documentElement).getPropertyValue(v).trim()}
function grow(){
  const s=+$("start").value,m=+$("monthly").value||0,r=+$("rate").value;
  $("startv").textContent=s; $("ratev").textContent=r+"%";
  const pts=project(s,m,r), last=pts[pts.length-1];
  $("final").textContent=fmt(last.bal); $("paid").textContent=fmt(last.paid); $("growth").textContent=fmt(last.bal-last.paid);
  draw(pts,s);
}
function niceMax(v){if(v<=0)return 1000;const p=Math.pow(10,Math.floor(Math.log10(v)));for(const k of[1,2,2.5,5,10])if(k*p>=v)return k*p;return 10*p}
function draw(pts,start){
  const c=$("chart"),dpr=window.devicePixelRatio||1,W=c.clientWidth,H=c.clientHeight;
  c.width=W*dpr;c.height=H*dpr;const x=c.getContext("2d");x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,W,H);
  const L=58,R=10,T=10,B=26,pw=W-L-R,ph=H-T-B,ymax=niceMax(Math.max(...pts.map(p=>p.bal)));
  const X=a=>L+(a-start)/(65-start)*pw, Y=v=>T+ph-v/ymax*ph;
  x.font="11px "+css("--mono");x.fillStyle=css("--muted");x.strokeStyle=css("--line");x.lineWidth=1;
  for(let i=0;i<=4;i++){const v=ymax*i/4,y=Y(v);x.beginPath();x.moveTo(L,y);x.lineTo(W-R,y);x.stroke();
    x.textAlign="right";x.textBaseline="middle";x.fillText(v>=1e6?"$"+(v/1e6).toFixed(v%1e6?1:0)+"M":"$"+Math.round(v/1000)+"k",L-8,y);}
  x.textAlign="center";x.textBaseline="top";
  const step=(65-start)>30?10:5;
  for(let a=Math.ceil(start/step)*step;a<=65;a+=step)x.fillText(a,X(a),H-B+8);
  const area=(key,col,alpha)=>{x.beginPath();x.moveTo(X(start),Y(0));pts.forEach(p=>x.lineTo(X(p.age),Y(p[key])));x.lineTo(X(65),Y(0));x.closePath();
    x.globalAlpha=alpha;x.fillStyle=col;x.fill();x.globalAlpha=1;};
  area("bal",css("--green"),.18);
  x.beginPath();pts.forEach((p,i)=>i?x.lineTo(X(p.age),Y(p.bal)):x.moveTo(X(p.age),Y(p.bal)));x.strokeStyle=css("--green");x.lineWidth=2.5;x.stroke();
  area("paid",css("--muted"),.35);
  const e=pts[pts.length-1];x.beginPath();x.arc(X(e.age),Y(e.bal),4.5,0,7);x.fillStyle=css("--green");x.fill();
}
["start","monthly","rate"].forEach(id=>$(id).addEventListener("input",grow));
window.addEventListener("resize",grow);
matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change",grow);
new MutationObserver(grow).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
grow(); document.fonts?.ready.then(grow);
