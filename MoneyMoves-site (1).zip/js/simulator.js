/* ===== First Year simulator engine ===== */
/* The settings and events live in content/simulator.js */
let S;
const snap=()=>({chk:S.chk,sav:S.sav,inv:S.inv,debt:S.debt,happy:S.happy,credit:S.credit});

function simNew(){
  S={m:0,chk:SIM.startCash,sav:0,inv:0,debt:0,card:false,credit:null,happy:70,flags:{},used:new Set(),log:[],earned:0,phase:"intro"};
  simDraw();
}
function simStats(){
  const t=$("simTrack");t.innerHTML=SHORT.map((_,i)=>`<span class="${i<S.m||S.phase==="end"?"done":i===S.m&&S.phase!=="intro"?"now":""}"></span>`).join("");
  const cell=(k,v,cls="")=>`<div><span class="k">${k}</span><span class="v ${cls}">${v}</span></div>`;
  $("simStats").innerHTML=
    cell("Month",S.phase==="end"?"Done":SHORT[S.m])+
    cell("Checking",money(S.chk),S.chk<0?"neg":"")+
    cell("Savings",money(S.sav))+
    cell("Invested",money(S.inv))+
    cell("Card debt",S.card?money(S.debt):"No card",S.debt>0?"neg":"")+
    cell("Credit score",S.credit??"None yet")+
    `<div><span class="k">Happiness</span><span class="v">${Math.round(S.happy)}</span><span class="hbar"><i style="width:${S.happy}%"></i></span></div>`;
}

/* covers a negative checking balance: savings first, then the card, then an overdraft fee */
function settle(){
  const msgs=[];
  if(S.chk<0&&S.sav>0){const c=Math.min(-S.chk,S.sav);S.sav-=c;S.chk+=c;msgs.push(`${money(c)} came out of your savings to cover it.`)}
  if(S.chk<0&&S.card){const c=Math.min(-S.chk,SIM.limit-S.debt);if(c>0){S.debt+=c;S.chk+=c;msgs.push(`${money(c)} went on your credit card at ${SIM.apr}% APR.`)}}
  if(S.chk<0){S.chk-=35;msgs.push("Your checking account was overdrawn, so the bank charged a $35 overdraft fee.")}
  return msgs;
}

function startMonth(){
  const summer=S.m>=9, hrs=summer?SIM.summerHours:SIM.schoolHours;
  const gross=SIM.rate*hrs*52/12, fica=gross*.0765, net=gross-fica;
  const bills=SIM.phone+SIM.gas+SIM.insurance+(S.flags.sub?SIM.sub:0);
  const interest=S.debt>0?S.debt*SIM.apr/1200:0;
  S.chk+=net-bills;S.earned+=net;S.debt+=interest;S.inv*=1.006;
  S.pay={hrs,summer,gross,fica,net,bills,interest,min:S.debt>0?Math.min(S.debt,Math.max(25,S.debt*.03)):0,debtBefore:S.debt,msgs:settle()};
  S.phase="pay";simDraw();
}

function renderPay(st){
  const p=S.pay,avail=floor5(Math.max(0,S.chk));
  const defSave=0,defFun=0,defPay=Math.min(Math.ceil(p.min/5)*5,avail);
  st.innerHTML=`<p class="eyebrow">${MONTHS[S.m]} · Payday</p>
  <h3>${p.summer?"Summer schedule. ":""}You got paid.</h3>
  <div class="ptable">
    <div><span>Gross pay (${p.hrs} hrs/week × ${money(SIM.rate)})</span><span>${money(p.gross)}</span></div>
    <div class="minus"><span>FICA taxes (7.65%)</span><span>−${money(p.fica)}</span></div>
    <div class="minus"><span>Bills: phone, gas, car insurance${S.flags.sub?", subscription":""}</span><span>−${money(p.bills)}</span></div>
    ${p.interest>0?`<div class="minus"><span>Interest added to card debt</span><span>+${money(p.interest)}</span></div>`:""}
    <div><span>Checking balance now</span><span>${money(S.chk)}</span></div>
  </div>
  ${p.msgs.map(m=>`<p class="warn">${m}</p>`).join("")}
  <p class="lead">Decide where your money goes this month. Anything you don't move stays in checking as a cushion for surprises.</p>
  <div class="alloc">
    <label for="simSave"><span class="row">Move to savings <b id="simSaveV"></b></span><input type="range" id="simSave" min="0" max="${avail}" step="5" value="${defSave}"></label>
    <label for="simFun"><span class="row">Fun money <b id="simFunV"></b></span><small>Food out, games, hanging out. Spending some keeps you happy.</small><input type="range" id="simFun" min="0" max="${avail}" step="5" value="${defFun}"></label>
    ${S.debt>0?`<label for="simPay"><span class="row">Pay toward card <b id="simPayV"></b></span><small>Minimum due: ${money(p.min)}. Paying less brings a $30 late fee and hurts your credit score.</small><input type="range" id="simPay" min="0" max="${Math.min(avail,Math.ceil(S.debt/5)*5)}" step="5" value="${defPay}"></label>`:""}
  </div>
  <p class="leftover">Left in checking: <b id="simLeft"></b></p>
  <div><button class="btn primary" id="simGo">Continue</button></div>`;
  const ids=["simSave","simFun","simPay"].filter(id=>$(id));
  const upd=e=>{
    let tot=ids.reduce((t,id)=>t+ +$(id).value,0);
    if(e&&tot>avail){e.target.value=floor5(+e.target.value-(tot-avail));tot=ids.reduce((t,id)=>t+ +$(id).value,0)}
    ids.forEach(id=>$(id+"V").textContent=money(+$(id).value));
    $("simLeft").textContent=money(S.chk-tot);
  };
  ids.forEach(id=>$(id).addEventListener("input",upd));upd();
  $("simGo").onclick=()=>{
    const s=+$("simSave").value,f=+$("simFun").value,pay=$("simPay")?Math.min(+$("simPay").value,S.debt):0;
    S.chk-=s+f+pay;S.sav+=s;S.debt=Math.max(0,S.debt-pay);
    S.happy=clamp(S.happy+Math.min(20,Math.floor(f/50)*4)-6,0,100);
    S.payNote="";
    if(S.card){
      if(p.debtBefore>0&&pay+.005<p.min){S.debt+=30;S.credit-=40;S.payNote="You paid less than the minimum. That's a $30 late fee and a big hit to your credit score."}
      else S.credit+=5;
      if(S.debt/SIM.limit>.3)S.credit-=6;
      S.credit=clamp(S.credit,300,850);
    }
    S.ev=pickEvent();S.phase="event";simDraw();
  };
}

function pickEvent(){
  const fixed=EVENTS.find(e=>e.month===S.m&&!S.used.has(e.id));
  if(fixed)return fixed;
  const forced=EVENTS.find(e=>e.forced&&S.flags[e.requires]&&!S.used.has(e.id));
  if(forced&&Math.random()<.7)return forced;
  const pool=EVENTS.filter(e=>e.month==null&&!e.forced&&!S.used.has(e.id)&&(!e.requires||S.flags[e.requires])&&(!e.needsCard||S.card)&&(e.maxMonth==null||S.m<=e.maxMonth));
  return pool.length?pick(pool):{id:"quiet"+S.m,title:"A quiet month",text:"Nothing unexpected happened this month.",choices:[{label:"Nice",fx:{happy:2},note:"Quiet months are the best time to build savings."}]};
}

function renderEvent(st){
  const e=S.ev;
  st.innerHTML=`<p class="eyebrow">${MONTHS[S.m]} · Something happened</p>
  ${S.payNote?`<p class="warn">${S.payNote}</p>`:""}
  <h3>${e.title}</h3><p class="lead">${e.text}</p>
  <p class="fine">You have ${money(Math.max(0,S.chk))} in checking and ${money(S.sav)} in savings.</p>
  <div class="choices">${e.choices.map((c,i)=>`<button class="opt choice" data-i="${i}">${c.label}</button>`).join("")}</div>`;
  st.querySelectorAll(".choice").forEach(b=>b.onclick=()=>{
    const c=e.choices[+b.dataset.i],out=c.run?c.run():{fx:c.fx,note:c.note},fx=out.fx,before=snap();
    if(fx.chk)S.chk+=fx.chk; if(fx.sav)S.sav+=fx.sav; if(fx.inv)S.inv+=fx.inv;
    if(fx.happy)S.happy=clamp(S.happy+fx.happy,0,100);
    if(fx.card){S.card=true;S.credit=650}
    if(fx.credit&&S.card)S.credit=clamp(S.credit+fx.credit,300,850);
    if(fx.set)S.flags[fx.set]=true;
    if(e.requires==="carDelay")S.flags.carDelay=false;
    S.used.add(e.id);
    S.res={title:e.title,label:c.label,note:out.note,msgs:settle(),before,after:snap()};
    S.log.push([MONTHS[S.m],e.title,c.label]);
    S.phase="result";simDraw();
  });
}

function fxChips(a,b){
  const L=[["chk","Checking",1],["sav","Savings",1],["inv","Invested",1],["debt","Card debt",1,1],["happy","Happiness"],["credit","Credit score"]];
  return L.map(([k,n,isMoney,bad])=>{
    if(k==="credit"&&a.credit==null&&b.credit!=null)return `<span class="fx up">Credit score starts at ${b.credit}</span>`;
    const d=(b[k]??0)-(a[k]??0);if(Math.abs(d)<.005)return "";
    const good=bad?d<0:d>0;
    return `<span class="fx ${good?"up":"down"}">${n} ${d>0?"+":"−"}${isMoney?money(Math.abs(d)):Math.round(Math.abs(d))}</span>`;
  }).join("");
}

function renderResult(st){
  const r=S.res,last=S.m===11;
  st.innerHTML=`<p class="eyebrow">${MONTHS[S.m]} · ${r.title}</p>
  <h3>You chose: ${r.label}</h3>
  <div class="effects">${fxChips(r.before,r.after)||'<span class="fx up">No change</span>'}</div>
  ${r.msgs.map(m=>`<p class="warn">${m}</p>`).join("")}
  <div class="lesson"><b>Money lesson:</b> ${r.note}</div>
  <div><button class="btn primary" id="simNext">${last?"See your year in review":"Next month: "+MONTHS[S.m+1]}</button></div>`;
  $("simNext").onclick=()=>{if(last){S.phase="end";simDraw()}else{S.m++;startMonth()}};
}

function renderEnd(st){
  const nw=S.chk+S.sav+S.inv-S.debt;
  const saved=S.sav+S.inv;
  const pts=40*clamp(saved/(.2*S.earned),0,1)+15*(S.debt<1?1:clamp(1-S.debt/SIM.limit,0,1)*.5)+25*S.happy/100+(S.card?20*clamp((S.credit-600)/150,0,1):12);
  const g=pts>=85?"A":pts>=70?"B":pts>=55?"C":pts>=40?"D":"F";
  const msg={A:"Excellent year. You saved, stayed out of debt, and still had a life.",B:"Strong year. A few choices cost you, but you finished in good shape.",C:"You got through it. See which choices cost you the most and try a different path.",D:"Rough year. Surprises hit hard without savings. Try paying yourself first next time.",F:"Money got away from you this year. Play again and build an emergency fund early."}[g];
  st.innerHTML=`<p class="eyebrow">August · Year in review</p>
  <div class="endgrid"><span class="grade">${g}</span><div style="display:grid;gap:8px;max-width:48ch"><h3>Your first year is done.</h3><p class="lead">${msg}</p></div></div>
  <div class="endstats">
    <span>Take-home pay earned</span><b>${money(S.earned)}</b>
    <span>Net worth (what you own − what you owe)</span><b>${money(nw)}</b>
    <span>Savings + invested</span><b>${money(S.sav+S.inv)}</b>
    <span>Card debt</span><b>${S.card?money(S.debt):"No card"}</b>
    <span>Credit score</span><b>${S.credit??"None yet"}</b>
    <span>Happiness</span><b>${Math.round(S.happy)}/100</b>
  </div>
  <div class="lesson"><b>What if:</b> saving 20% of every paycheck would have added ${money(S.earned*.2)} to your savings this year. You saved and invested ${money(saved)}${S.chk>300?`, and ${money(S.chk)} is sitting in checking. Money left in checking earns nothing, so moving it to savings counts more`:""}.</div>
  <h3 style="font-size:1.1rem">Your choices</h3>
  <div class="timeline">${S.log.map(([m,t,c])=>`<div><span>${m.slice(0,3)}</span><span><b>${t}:</b> ${c}</span></div>`).join("")}</div>
  <div><button class="btn primary" id="simAgain">Play again</button></div>`;
  $("simAgain").onclick=simNew;
}

function simDraw(){
  simStats();const st=$("simStage");
  if(S.phase==="intro"){
    st.innerHTML=`<p class="eyebrow">Your situation</p><h3>You're 17, a senior, with your first job.</h3>
    <p class="lead">You earn ${money(SIM.rate)} an hour working ${SIM.schoolHours} hours a week during school, and ${SIM.summerHours} in the summer. Every month you pay $${SIM.phone} for your phone, $${SIM.gas} for gas, and $${SIM.insurance} toward car insurance. You're starting with ${fmt(SIM.startCash)} in checking.</p>
    <p class="lead">Each month you'll get paid, split up your money, and handle one surprise. At the end you get a grade based on how much you saved, your debt, your credit, and your happiness. Money left sitting in checking doesn't count as saved.</p>
    <div><button class="btn primary" id="simStart">Start in September</button></div>`;
    $("simStart").onclick=startMonth;
  }else if(S.phase==="pay")renderPay(st);
  else if(S.phase==="event")renderEvent(st);
  else if(S.phase==="result")renderResult(st);
  else renderEnd(st);
}
simNew();
