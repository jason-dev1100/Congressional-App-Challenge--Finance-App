/* flashcards */
let fDeck=[],fKnown=0,fBackFirst=false;
const fcard=$("fcard");
function fStart(){fDeck=shuffle(TERMS.map((_,i)=>i));fKnown=0;$("fplay").hidden=false;$("fdone").hidden=true;fShow()}
function fShow(){
  $("fprog").textContent=`${fKnown} of ${TERMS.length} mastered · ${fDeck.length} left`;
  $("fmeter").style.width=fKnown/TERMS.length*100+"%";
  if(!fDeck.length){$("fplay").hidden=true;$("fdone").hidden=false;return}
  const [t,d]=TERMS[fDeck[0]];
  fcard.classList.remove("flipped");
  $("ftx1").textContent=fBackFirst?d:t;$("ftx2").textContent=fBackFirst?t:d;
  $("flab1").textContent=fBackFirst?"Definition":"Term";$("flab2").textContent=fBackFirst?"Term":"Definition";
  document.querySelector(".ffront").style.font=fBackFirst?"500 1.12rem/1.5 var(--body)":"";
  document.querySelector(".fback").style.font=fBackFirst?"800 clamp(1.4rem,4vw,1.9rem)/1.15 var(--display)":"";
}
fcard.onclick=()=>fcard.classList.toggle("flipped");
$("fgot").onclick=()=>{fDeck.shift();fKnown++;fShow()};
$("fagain").onclick=()=>{const c=fDeck.shift();fDeck.splice(Math.min(3,fDeck.length),0,c);fShow()};
$("fback").onchange=e=>{fBackFirst=e.target.checked;fShow()};
$("frestart").onclick=fStart;
fStart();
