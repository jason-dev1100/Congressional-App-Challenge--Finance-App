# How to edit MoneyMoves

The site is plain HTML, CSS, and JavaScript. You don't need to compile or install anything: edit a file, save it, and refresh the page.

## Where everything lives

| I want to change... | Edit this file |
|---|---|
| Quiz questions | `content/quiz.js` |
| Flashcard + matching game terms | `content/terms.js` |
| "Need or want?" and "Spot the scam" items | `content/games.js` |
| Simulator events, wage, hours, bills | `content/simulator.js` |
| Lesson text, headings, page sections | `index.html` |
| Colors, fonts, spacing, layout | `style.css` |
| How the simulator works (paydays, credit score, grading) | `js/simulator.js` |
| Drill problems (formulas) | `js/drills.js` |
| Practice sheet scenarios | `js/sheets.js` |
| Budget + growth calculators | `js/calculators.js` |
| AI tutor (Penny) instructions | `js/tutor.js` |

**Start with the `content/` folder.** Those files are mostly lists, so they're the easiest place to make changes.

## Common edits

### Add a quiz question (`content/quiz.js`)
Copy any question, paste it as a new line inside the list, and change it:
```js
 {q:"What is a 401(k)?",o:["A retirement account through your job","A type of loan","A credit score","A tax form"],a:0,e:"A 401(k) is a retirement account offered by employers."},
```
- `q` is the question and `o` is the list of choices.
- `a` is the position of the right answer, **counting from 0**. The first choice is 0, the second is 1, and so on.
- `e` is the explanation shown after someone answers.

### Add a flashcard term (`content/terms.js`)
```js
 ["Budget deficit","Spending more money than you bring in"],
```
New terms automatically show up in both the flashcards and the matching game.

### Add a simulator event (`content/simulator.js`)
Copy an existing event inside `EVENTS` and change it:
```js
 {id:"jersey",title:"Team jersey",text:"Your cross country team is ordering custom jerseys for $65.",choices:[
  {label:"Buy one: $65",fx:{chk:-65,happy:6},note:"Team gear is a want, but it can be worth budgeting for."},
  {label:"Skip it",fx:{happy:-3},note:"You can still be part of the team without it."}]},
```
- `id` must be unique, with no spaces.
- `fx` controls what a choice does:
  - `chk`: checking account change (negative means spending)
  - `sav`: savings change
  - `inv`: investment change
  - `happy`: happiness change
  - `credit`: credit score change (only applies once the player has a card)
- `note` is the money lesson shown after the choice.
- Optional settings:
  - `month:3` makes the event happen in a fixed month, counted from 0, so 3 means December.
  - `maxMonth:4` means the event can only happen up to that month.
  - `needsCard:true` means it only appears once the player has a credit card.
  - `set:"flagName"` on a choice, together with `requires:"flagName"` on another event, makes that event a follow-up to the choice.

To change the job or bills, edit the numbers in `SIM` at the top of the same file, like `rate:12` or `phone:40`.

### Change colors (`style.css`)
All colors are set in the first few lines:
- `:root { ... }` sets the light-mode colors.
- The two blocks after it set the dark-mode colors.

Change `--green` to change the main accent color everywhere.

## Watch out for
- **Commas.** Every item in a list needs a comma after it, except the last one, where it's optional. A missing comma is the most common reason the page breaks.
- **Quotes inside text.** Write `\"` for a quote mark inside text that's already in quotes, like this: `"He said \"hi\""`.
- **If the page goes blank or a section stops working:** right-click the page, choose Inspect, and open the Console tab. It shows the file and line number of the error.

## Working together
- Each person edits in their own Codespace and commits their own changes with a clear message, like "Add 3 NC-specific simulator events."
- Click **Sync Changes** before you start working, so you have your partner's latest changes.
- Your commit history on GitHub shows who built what, which also documents your individual contributions for the Congressional App Challenge.
- To preview while you edit, install the **Live Preview** extension in the Codespace, then right-click `index.html` and choose "Show Preview."

## Credits
- Fonts: Google Fonts (Bricolage Grotesque, Public Sans, JetBrains Mono)
- The initial version of the site was built with help from Claude (Anthropic). Document your own changes in your AI disclosure.
